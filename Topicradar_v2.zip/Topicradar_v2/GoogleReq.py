from selenium import webdriver
import pandas as pd
from bs4 import BeautifulSoup
import re
import time

def trends_ONLY_JSON(RC):
	############################ Pulls Data ##########################
	#driver = webdriver.Chrome('C:/Users/tazma/Documents/TopicRadar/chromedriver')
	driver = webdriver.Chrome('./chromedriver')

	
	realtime_URL = driver.get('https://trends.google.com/trends/trendingsearches/realtime?geo='+RC+'&category=all')
	#grabs raw html
	time.sleep(2)
	#grabs raw html
	html = driver.page_source
	soup = BeautifulSoup(html, 'html.parser')
	driver.quit()
	#########################################################
	Trend_JSON = parse_data(soup)
		
	#if len(Trend_JSON) == 0:
		#print('Trents are empty, running with daily_url')
		#daliy_URL = driver.get('https://trends.google.com/trends/trendingsearches/daily?geo=US')
		##grabs raw html
		#html = driver.page_source
		#soup = BeautifulSoup(html, 'html.parser')
		#driver.quit()
		#Trend_JSON = parse_data(soup)
		
	return Trend_JSON
	
	
def parse_data(soup):
	#grabs content puts it in a dict
	Trend_JSON = []
	id = 0
	
	for x in soup.find_all('div', class_='feed-item contracted-item'):
		title = re.sub(r'\s+', ' ',x.find(class_='title').text).strip()
		title = title.replace("•", "")
		trend_id = id
		id = id + 1
		temp_dict = {'Title':title, 'Trend_id' : trend_id}
		Trend_JSON.append(temp_dict)

	return Trend_JSON