import { Injectable } from '@angular/core';
// import { Http } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';


import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, filter, scan, reduce } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  ROOT_URL2 = 'http://127.0.0.1:5000/region/';
  ROOT_URL = 'http://127.0.0.1:5000/';

  currentCountry = 'US';
  Default =true;
  myData: Observable<Data>;

  constructor(public http: HttpClient) {
    console.log('Data service connected...');

  }

  getPosts() {
	var url = this.getCountryCode(this.ROOT_URL);
    return this.http.get<Data>(url); // ;
  }

  getCountryCode(url) {
    if (this.Default === true) {
      return url;
    } else { return url + 'region/' + this.currentCountry ;  } }


  setLocation(name: string) {
    this.currentCountry = name;
	this.Default = false;
  }


}

interface Data {
  _id: string;
  date_added: string;
  location_tag: string;
  trends: Trend[];
}

interface Trend {
  trend_id: string;
  trend_name: string;
  articles: Article[];

}

interface Article {
  article_URL: string;
  article_id: string;
  article_post_date: string;
  article_thumbnail: string;
  atrticle_title: string;

}
