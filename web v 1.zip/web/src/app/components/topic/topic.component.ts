import { Component, OnInit } from '@angular/core';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-topic',
  templateUrl: './topic.component.html',
  styleUrls: ['./topic.component.css']
})
export class TopicComponent implements OnInit {

  topics: Topic[];

  constructor(private dataService: DataService) {

  }

  ngOnInit() {

    this.dataService.getTopics('USA').subscribe((topics) => {
      console.log(topics);
      console.log('abc');
    });

  }

}

interface Topic {
  id: number;

}

interface Article {
  id: number;
}
console.log('abc');
