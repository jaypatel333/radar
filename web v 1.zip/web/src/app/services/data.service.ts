import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  country = '';
  url = '';

  constructor(public http: Http) {


  }

  getTopics(country) {

    country = this.getCountryCode(country);
    console.log('abcccccccc');
    this.url = 'https://reqres.in/api/list/';
    this.url += country;
    return this.http.get(this.url).pipe(map((response: any) => response.json()));
      // .map(res => res.json());
  }

  getCountryCode(c) {
    return 1;

  }

}

